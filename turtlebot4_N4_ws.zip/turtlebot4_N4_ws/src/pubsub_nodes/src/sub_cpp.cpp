#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

class Sub : public rclcpp::Node
{
public:
    Sub() : Node("sub")
    {
        subscription = this->create_subscription<std_msgs::msg::String>("topic", 10,
             [this](const std_msgs::msg::String::SharedPtr msg) {
                RCLCPP_INFO(this->get_logger(), "I heard; '%s'", msg->data.c_str());
             });
    }
private:
    rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription;
};

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<Sub>());
    rclcpp::shutdown();
    return 0;
}