import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class PubSub(Node):
    def __init__(self):
        super().__init__('pubsub_py')
        self.publisher = self.create_publisher(String, 'processed_topic', 10)
        self.subscription = self.create_subscription(String, 'topic', self.listener_callback, 10)
        self.count = 0

    def listener_callback(self, msg):
        self.count += 1
        processed_msg = String()
        processed_msg.data = (f'[Processed {self.count}] {msg.data}')
        self.publisher.publish(processed_msg)
        self.get_logger().info(f'Published processed: "{processed_msg.data}"')

def main():
    rclpy.init()
    node = PubSub()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
