from setuptools import setup

setup(
    name='pubsub_py_nodes',
    version='0.0.0',
    packages=['pubsub_py_nodes'],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='N4',
    maintainer_email='thefaultlessone@gmail.com',
    description='Python pub/sub nodes',
    entry_points={
        'console_scripts': [
            'pub_py = pubsub_py_nodes.pub_py:main',
            'sub_py = pubsub_py_nodes.sub_py:main',
            'pubsub_py = pubsub_py_nodes.pubsub_py:main',
        ]
    },
)
